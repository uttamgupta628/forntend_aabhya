// components/DonationForm.tsx
import { useState } from "react";

type CauseType = "" | "general" | "food" | "clothes" | "education" | "medical";
type YesNo = "" | "yes" | "no";

const CAUSE_OPTIONS: { value: CauseType; label: string }[] = [
  { value: "",          label: "Select One Option" },
  { value: "general",   label: "General Donation" },
  { value: "food",      label: "Food" },
  { value: "clothes",   label: "Clothes" },
  { value: "education", label: "Education" },
  { value: "medical",   label: "Medical Aids" },
];

const HandIcon = () => (
  <svg width="38" height="38" viewBox="0 0 24 24" fill="none">
    {/* Heart */}
    <path
      d="M12 8.6c-.9-1.6-2.4-2.4-3.9-2.1-1.8.3-3 1.9-2.9 3.7.2 3 3.7 5.4 6.8 7.4 3.1-2 6.6-4.4 6.8-7.4.1-1.8-1.1-3.4-2.9-3.7-1.5-.3-3 .5-3.9 2.1z"
      fill="#e8490f"
    />
    {/* Cupped hand underneath */}
    <path
      d="M4 15.5c0-.9.7-1.5 1.5-1.5h13c.8 0 1.5.6 1.5 1.5 0 2.6-1.7 4.8-4.2 5.6-1.2.4-2.5.6-3.8.6s-2.6-.2-3.8-.6c-2.5-.8-4.2-3-4.2-5.6z"
      stroke="#e8490f" strokeWidth="1.6" strokeLinejoin="round"
    />
  </svg>
);

export default function DonationForm() {
  const [cause,       setCause]       = useState<CauseType>("");
  const [amount,      setAmount]      = useState("");
  const [name,        setName]        = useState("");
  const [email,       setEmail]       = useState("");
  const [phone,       setPhone]       = useState("");
  const [aadhar,      setAadhar]      = useState("");
  const [taxBenefit,  setTaxBenefit]  = useState<YesNo>("");
  const [citizen,     setCitizen]     = useState<YesNo>("");
  const [agreed,      setAgreed]      = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!agreed) return;
    console.log({ cause, amount, name, email, phone, aadhar, taxBenefit, citizen });
  }

  const label = "block text-sm font-bold text-[#e8490f] mb-1.5";

  const inp =
    "w-full border border-gray-200 rounded-md px-3.5 py-2.5 text-sm text-gray-700 " +
    "placeholder:text-gray-400 focus:outline-none focus:border-[#e8490f] " +
    "focus:ring-2 focus:ring-[#e8490f]/10 transition-colors bg-white";

  const select =
    "w-full border rounded-md px-3.5 py-2.5 text-sm text-gray-700 bg-white " +
    "focus:outline-none focus:ring-2 focus:ring-[#e8490f]/10 transition-colors appearance-none " +
    "border-[#e8490f]";

  const RadioRow = ({
    value, onChange,
  }: { value: YesNo; onChange: (v: YesNo) => void }) => (
    <div className="flex items-center gap-6 mt-1.5">
      {(["yes", "no"] as const).map(opt => (
        <label key={opt} className="flex items-center gap-2 cursor-pointer group">
          <div
            onClick={() => onChange(opt)}
            className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors
              ${value === opt ? "border-[#e8490f]" : "border-gray-300 group-hover:border-gray-400"}`}
          >
            {value === opt && <div className="w-2 h-2 rounded-full bg-[#e8490f]" />}
          </div>
          <span className="text-sm text-gray-700 capitalize">{opt}</span>
        </label>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4 py-12">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 w-full max-w-3xl mx-auto p-8">

        {/* ── Heading ── */}
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-extrabold !text-[#e8490f] tracking-wide">
            DONATION NOW
          </h2>
          <div className="flex justify-center mt-2">
            <HandIcon />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-x-8 gap-y-5">

          {/* I Want to Donate for */}
          <div>
            <label className={label}>I Want to Donate for *</label>
            <select
              className={select}
              value={cause}
              onChange={e => setCause(e.target.value as CauseType)}
            >
              {CAUSE_OPTIONS.map(({ value, label: l }) => (
                <option key={value || "placeholder"} value={value}>{l}</option>
              ))}
            </select>
          </div>

          {/* Amount */}
          <div>
            <label className={label}>Amount Donation In Number</label>
            <input
              className={inp}
              type="number"
              placeholder="Amount Donation*"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              min="1"
            />
          </div>

          {/* Name */}
          <div>
            <label className={label}>Name</label>
            <input
              className={inp}
              placeholder="Enter Name*"
              value={name}
              onChange={e => setName(e.target.value)}
            />
          </div>

          {/* Email */}
          <div>
            <label className={label}>Email</label>
            <input
              className={inp}
              type="email"
              placeholder="Enter Email*"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
          </div>

          {/* Phone Number */}
          <div>
            <label className={label}>Phone Number</label>
            <div className="flex">
              <span className="flex items-center gap-1 px-3 border border-r-0 border-gray-200
                               rounded-l-md bg-[#faf9f7] text-sm text-gray-600 shrink-0">
                🇮🇳 +91
              </span>
              <input
                className={inp + " rounded-l-none"}
                type="tel"
                placeholder="Phone Number*"
                value={phone}
                onChange={e => setPhone(e.target.value)}
              />
            </div>
          </div>

          {/* Aadhar Card Number */}
          <div>
            <label className={label}>Aadhar Card Number</label>
            <input
              className={inp}
              placeholder="Aadhar Card Number"
              value={aadhar}
              onChange={e => setAadhar(e.target.value)}
            />
          </div>

          {/* 80G Tax Benefit */}
          <div>
            <label className="block text-sm font-bold text-[#0d2b2b] mb-1.5">
              Do You Want 80G Tax Benefit
            </label>
            <RadioRow value={taxBenefit} onChange={setTaxBenefit} />
          </div>

          {/* Citizen In India */}
          <div>
            <label className="block text-sm font-bold text-[#0d2b2b] mb-1.5">
              Are You Citizen In India*
            </label>
            <RadioRow value={citizen} onChange={setCitizen} />
          </div>
        </div>

        {/* Note */}
        <p className="text-xs text-[#1a4fd6] leading-relaxed mt-5">
          Please Tick this Box if you are a Taxpayer in India and would like to avail Tax Benifits
          under 80G. To avail this, you need to Provide your PAN/Aadhar Number
        </p>

        {/* Agree + Submit */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-5">
          <label className="flex items-start gap-2.5 cursor-pointer group">
            <div
              onClick={() => setAgreed(!agreed)}
              className={`mt-0.5 w-4 h-4 min-w-[16px] rounded border-2 flex items-center justify-center transition-colors
                ${agreed ? "bg-[#e8490f] border-[#e8490f]" : "border-gray-300 group-hover:border-gray-400"}`}
            >
              {agreed && (
                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              )}
            </div>
            <span className="text-xs text-gray-600 leading-relaxed">
              I agree and accept that donation are not refundable under any circumstances. *
            </span>
          </label>

          <button
            onClick={handleSubmit}
            disabled={!agreed}
            className={`shrink-0 px-8 py-3 rounded-md font-bold tracking-wide uppercase text-sm
                        text-white transition-colors duration-200 whitespace-nowrap
                        ${agreed
                          ? "bg-[#e8490f] hover:bg-[#d43d09] cursor-pointer"
                          : "bg-[#e8490f]/50 cursor-not-allowed"}`}
          >
            Donate Now
          </button>
        </div>

      </div>
    </div>
  );
}